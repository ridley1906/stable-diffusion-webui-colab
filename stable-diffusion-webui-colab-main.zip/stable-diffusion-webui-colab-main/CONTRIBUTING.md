#### Video Tutorial
https://www.youtube.com/watch?v=XdjOiZkS6PU

#### Please add the token if it exists
Example: papercut_diffusion_webui_colab (Use the tokens `PaperCut` in your prompts for the effect.)

If you joined our discord server https://discord.gg/k5BwmmvJJU, please tell me your discord username.